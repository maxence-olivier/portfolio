
fprintf('1 : Mode Simulation (Créer des données)\n');
fprintf('2 : Mode Chemin Inverse (Analyser un fichier existant)\n');

% =========================================================================
% TITRE : BRUIT : Générateur de bruit gaussien paramétré
%
% Description :
%   Cette fonction génère un vecteur de bruit aléatoire suivant une
%   distribution normale (gaussienne) centrée, avec un écart-type choisi.
%   Elle affiche également des graphiques d'analyse du bruit généré.
%
% Syntaxe :
%   b = bruit(n, sigma)
%
% Paramètres d'entrée :
%   n      : nombre d'échantillons du bruit à générer
%   sigma  : écart-type du bruit (intensité du bruit)
%
% Sortie :
%   b : vecteur ligne contenant le bruit aléatoire généré
%
% Exemple :
%   b = bruit(200,0.5);
%
% Remarques :
%   - Si sigma n'est pas fourni → sigma = 0.1 par défaut
%   - Si n n'est pas fourni → n = 100 par défaut
%   - Le bruit suit une loi normale N(0, sigma²)
%
% Auteur : VALENTIN
% Date création : 2026-02-16
% Version : 12
% =========================================================================



% Déclaration de la fonction avec 2 entrées : n et sigma
function b = bruit(n, sigma, type_bruit)

% Vérification des arguments

% Sécurité si on lance le fichier seul
% nargin = nombre d'arguments réellement fournis à la fonction
% Si l'utilisateur ne fournit pas sigma

% Valeur par défaut de l'écart-type


% Si l'utilisateur ne fournit pas n
% Nombre de points par défaut

% Génération du bruit

% Calcul du bruit avec le sigma choisi
% randn(1,n) génère un vecteur ligne de n valeurs aléatoires
% suivant une loi normale centrée réduite N(0,1)
% En multipliant par sigma, on obtient N(0, sigma²)
    % Par défaut, si non précisé, on reste sur Gaussien (1)
    if nargin < 3, type_bruit = 1; end
    if nargin < 2, sigma = 0.1; end
    if nargin < 1, n = 100; end

    if type_bruit == 1
        % BRUIT GAUSSIEN (Loi Normale)
        b = sigma * randn(1, n);
        nom_bruit = 'Gaussien';
    else
        % BRUIT UNIFORME
        % rand(1,n) génère entre 0 et 1. 
        % (rand-0.5)*2 génère entre -1 et 1.
        b = sigma * (rand(1, n) - 0.5) * 2;
        nom_bruit = 'Uniforme';
    end
% Premier graphique d'analyse
figure
subplot(1,2,1) % Crée une figure divisée en 1 ligne et 2 colonnes
plot(b)% Trace le signal bruité
% Titre dynamique affichant la valeur du sigma utilisé
title(['Bruit gaussien', nom_bruit '(\sigma = ', num2str(sigma), ')'])
xlabel('n'); % Nom axe horizontal
ylabel('Amplitude'); % Nom axe vertical

% Second graphique Histogramme statistique
subplot(1,2,2) 
histogram(b, 100) % Histogramme avec 100 classes (bins)
title(['Histogramme du bruit',nom_bruit]); % Titre du graphique
xlabel('Amplitude'); % Nom axe horizontal
ylabel('Frequence'); % Nom axe vertical
end