function [choix_final, stats] = analyse_automatique(x, y_total, mode_affichage, ax)

    if nargin < 3 || isempty(mode_affichage)
        mode_affichage = false; % Toujours false pour l'IHM
    end
    if nargin < 4, ax = []; end

    noms = {'Lineaire', 'Logarithmique', 'Exponentiel', 'Puissance'};
    couleurs_courbes = {'b','m','g','c'};

    scores_R2 = zeros(4,1);
    params_p0 = zeros(4,1);
    params_p1 = zeros(4,1);

    % Affichage uniquement dans les axes IHM
    if ~isempty(ax)
        cla(ax); hold(ax,'on'); grid(ax,'on');
        plot(ax, x, y_total,'r.','MarkerSize',12);
    end

    % Test des 4 modèles
    for t = 1:4
        y_c = y_total; y_c(y_c<=0) = 1e-4;

        try
            switch t
                case 1; p = polyfit(x, y_total, 1); p0_e = p(1); p1_e = p(2);
                case 2; p = polyfit(log(x), y_total, 1); p0_e = p(1); p1_e = p(2);
                case 3; p = polyfit(x, log(y_c), 1); p1_e = p(1); p0_e = exp(p(2));
                case 4; p = polyfit(log(x), log(y_c), 1); p0_e = p(1); p1_e = exp(p(2));
            end

            y_fit = simu_sys(x, t, p0_e, p1_e);

            SS_res = sum((y_total - y_fit).^2);
            SS_tot = sum((y_total - mean(y_total)).^2);
            R2 = 1 - SS_res/SS_tot;

            scores_R2(t) = R2;
            params_p0(t) = p0_e; params_p1(t) = p1_e;

            % Affichage uniquement si axes fournis
            if ~isempty(ax)
                plot(ax, x, y_fit, couleurs_courbes{t}, 'LineWidth',2);
            end
        catch
        end
    end

    % Meilleur modèle
    [~, idx] = max(scores_R2);
    choix_final = noms{idx};
    p0_final = params_p0(idx);
    p1_final = params_p1(idx);

    if ~isempty(ax)
        y_best = simu_sys(x, idx, p0_final, p1_final);
        plot(ax, x, y_best, 'k--','LineWidth',2);
        legend(ax, {'Données','Lineaire','Logarithmique','Exponentiel','Puissance','Meilleur'},'Location','best');
        hold(ax,'off');
    end

    stats = table(noms', scores_R2, params_p0, params_p1,...
                  'VariableNames', {'Modele','Score_R2','P0_Estime','P1_Estime'});
end