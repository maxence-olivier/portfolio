% =========================================================================
% TITRE : SIMU_SYS : Générateur de fonctions mathématiques paramétriques
%
% Description :
%   Cette fonction calcule y à partir d'un vecteur x selon un modèle
%   mathématique choisi par l'utilisateur.
%
% Syntaxe :
%   y = simu_sys(x, type_fct, p0, p1)
%
% Paramètres d'entrée :
%   x        : vecteur ou scalaire (valeurs d'entrée)
%   type_fct : entier définissant le modèle :
%              1 : fonction affine        : y = p0*x + p1
%              2 : logarithmique          : y = p0*log(x) + p1
%              3 : exponentielle          : y = p0*exp(p1*x)
%              4 : puissance              : y = p1*x^p0
%   p0       : paramètre numérique
%   p1       : paramètre numérique
%
% Sortie :
%   y : résultat du calcul (même taille que x)
%
% Exemple :
%   x = linspace(0.1,30,100);
%   y = simu_sys(x,1,2,5);
%   plot(x,y)
%
% Remarques :
%   - x doit être strictement positif pour type_fct = 2 (logarithme).
%   - L'opérateur .^ est utilisé pour supporter les vecteurs.
%
% Auteur : VALENTIN
% Date création : 2026-02-16
% Version : 8
% =========================================================================





% PARTIE FONCTION

% Déclaration de la fonction
% Nom : simu_sys
% Entrées :
%   x        → variable indépendante (scalaire ou vecteur)
%   type_fct → entier qui choisit la formule mathématique
%   p0, p1   → paramètres numériques utilisés dans les calculs
% Sortie :
%   y        → résultat du calcul
function y = simu_sys(x, type_fct, p0, p1)
% Calcule y selon le type de modèle choisi
% type_fct : 1=Linéaire, 2=Logarithmique, 3=Exponentielle, 4=Puissance
% x doit être >0 pour log/power

x(x<=0) = 1e-6; % sécurité pour log/power

switch type_fct
    case 1 % linéaire
        y = p0*x + p1;
    case 2 % logarithmique
        y = p0*log(x) + p1;
    case 3 % exponentielle
        y = p0*exp(p1*x);
    case 4 % puissance
        y = p1*x.^p0;
    otherwise
        error('Type de fonction inconnu');
end
