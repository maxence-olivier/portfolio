    mode_choisi = input(['Choisissez entre :\n'...
                     '1: Simulation de nouvelles données\n'...
                     '2: Analyse automatique d''un fichier existant\n'...
                     'Votre choix : ']);

function [choix_final, stats] = analyse_automatique(x, y_total)
    % Noms des suspects (modèles)
    noms = {'Lineaire', 'Logarithmique', 'Exponentiel', 'Puissance'};
    couleurs = {'r', 'b', 'm', 'g'}; 
    scores_R2 = zeros(4,1);
    params_p0 = zeros(4,1);
    params_p1 = zeros(4,1);

    % --- FIGURE 1 : LES DONNÉES BRUTES ---
    figure(1); clf; % On force la figure 1 et on l'efface
    plot(x, y_total, 'k.', 'MarkerSize', 10);
    grid on; title('Figure 1 : Signal Inconnu reçu (Données Brutes)');
    xlabel('X'); ylabel('Y');

    % --- BOUCLE DE TEST DES 4 MODÈLES ---
    for t = 1:4
        y_c = y_total; 
        y_c(y_c <= 0) = 0.0001; % Sécurité pour les logs
        
        % Calcul de la régression selon le modèle t
        try
            switch t
                case 1 % LINÉAIRE (y = p0*x + p1)
                    p = polyfit(x, y_total, 1);
                    p0_e = p(1); p1_e = p(2);
                case 2 % LOGARITHMIQUE (y = p0*log(x) + p1)
                    p = polyfit(log(x), y_total, 1);
                    p0_e = p(1); p1_e = p(2);
                case 3 % EXPONENTIEL (y = p0*exp(p1*x))
                    p = polyfit(x, log(y_c), 1);
                    p1_e = p(1); p0_e = exp(p(2));
                case 4 % PUISSANCE (y = p1*x^p0)
                    p = polyfit(log(x), log(y_c), 1);
                    p0_e = p(1); p1_e = exp(p(2));
            end
            
            % Génération de la courbe pour le graphique
            y_fit = simu_sys(x, t, p0_e, p1_e);
            
            % Calcul du score R²
            SS_res = sum((y_total - y_fit).^2);
            SS_tot = sum((y_total - mean(y_total)).^2);
            R2 = 1 - SS_res/SS_tot;
            
            % Stockage des résultats
            scores_R2(t) = R2;
            params_p0(t) = p0_e;
            params_p1(t) = p1_e;

            % --- AFFICHAGE DE LA FIGURE DE TEST (On commence à la figure 2) ---
            figure(t + 1); clf; % Crée Figure 2, 3, 4 et 5
            plot(x, y_total, 'k.', 'DisplayName', 'Points réels'); hold on;
            plot(x, y_fit, couleurs{t}, 'LineWidth', 2, 'DisplayName', ['Modèle ', noms{t}]);
            title(['Test ', num2str(t), ' : ', noms{t}, ' (R² = ', num2str(R2, 4), ')']);
            legend show; grid on;
            
        catch
            fprintf('Le test du modèle %s a échoué.\n', noms{t});
        end
    end

    % --- VERDICT FINAL ---
    [meilleur_score, idx] = max(scores_R2);
    choix_final = noms{idx};
    
    % Tableau de synthèse
    stats = table(noms', scores_R2, params_p0, params_p1, ...
        'VariableNames', {'Modele', 'Score_R2', 'P0_Estime', 'P1_Estime'});
    
    fprintf('\n========================================\n');
    fprintf('   RÉSULTATS DE L''ANALYSE AUTOMATIQUE\n');
    fprintf('========================================\n');
    disp(stats);
    fprintf('>>> VERDICT : Le modèle le plus probable est : %s\n', choix_final);
    fprintf('>>> Qualité de l''ajustement (R²) : %.4f\n', meilleur_score);
    fprintf('========================================\n');
end

function [choix_final, stats] = analyse_automatique(x, y_total)
    % Noms des suspects (modèles)
    noms = {'Lineaire', 'Logarithmique', 'Exponentiel', 'Puissance'};
    couleurs = {'r', 'b', 'm', 'g'}; % Une couleur par test
    scores_R2 = zeros(4,1);
    params_p0 = zeros(4,1);
    params_p1 = zeros(4,1);

    % --- FIGURE 1 : LE NUAGE DE POINTS SEUL (La donnée brute) ---
    figure('Name', 'Analyse Automatique - Données Brutes');
    plot(x, y_total, 'k.', 'MarkerSize', 10);
    grid on; title('Figure 1 : Signal Inconnu reçu');
    xlabel('X'); ylabel('Y');

    % --- BOUCLE DE TEST (Figure 2, 3, 4, 5) ---
    for t = 1:4
        y_c = y_total; y_c(y_c <= 0) = 0.0001; % Sécurité
        
        % Calcul du modèle
        switch t
            case 1 % Lin
                p = polyfit(x, y_total, 1);
                p0_e = p(1); p1_e = p(2);
            case 2 % Log
                p = polyfit(log(x), y_total, 1);
                p0_e = p(1); p1_e = p(2);
            case 3 % Exp
                p = polyfit(x, log(y_c), 1);
                p1_e = p(1); p0_e = exp(p(2));
            case 4 % Puiss
                p = polyfit(log(x), log(y_c), 1);
                p0_e = p(1); p1_e = exp(p(2));
        end
        
        % Simulation du résultat pour calcul du score
        y_fit = simu_sys(x, t, p0_e, p1_e);
        SS_res = sum((y_total - y_fit).^2);
        SS_tot = sum((y_total - mean(y_total)).^2);
        R2 = 1 - SS_res/SS_tot;
        
        % Stockage
        scores_R2(t) = R2;
        params_p0(t) = p0_e;
        params_p1(t) = p1_e;

        % Affichage de chaque test dans une nouvelle figure
        figure('Name', ['Test Modèle ', noms{t}]);
        plot(x, y_total, 'k.', 'DisplayName', 'Points'); hold on;
        plot(x, y_fit, couleurs{t}, 'LineWidth', 2, 'DisplayName', noms{t});
        title(['Modèle ', noms{t}, ' (R² = ', num2str(R2, 4), ')']);
        legend show; grid on;
    end

    % --- SYNTHÈSE ET VERDICT ---
    [meilleur_score, idx] = max(scores_R2);
    choix_final = noms{idx};
    
    % Création du tableau de comparaison
    stats = table(noms', scores_R2, params_p0, params_p1, ...
        'VariableNames', {'Systeme', 'R2', 'P0_estime', 'P1_estime'});
    
    % Calcul de la "probabilité" (IA simple par poids de R2)
    poids = exp(scores_R2 * 10); % Accentue les différences
    pourcentages = (poids / sum(poids)) * 100;
    
    fprintf('\n--- VERDICT DE L''ANALYSE ---\n');
    fprintf('Le système semble être : %s (Score R²: %.4f)\n', choix_final, meilleur_score);
    fprintf('Fiabilité du choix : %.1f %%\n', pourcentages(idx));
    
    % Estimation du Sigma (Bruit) sur le meilleur modèle
    residus = y_total - simu_sys(x, idx, params_p0(idx), params_p1(idx));
    sigma_est = std(residus);
    fprintf('Intensité du bruit estimée (Sigma) : %.3f\n', sigma_est);
end




function [meilleur_type, p_estim, sigma_est, tableau_R2] = analyse_automatique(x, y_total)
    % Initialisation
    noms = {'Lineaire', 'Logarithmique', 'Exponentiel', 'Puissance'};
    scores_R2 = zeros(4,1);
    p0_all = zeros(4,1);
    p1_all = zeros(4,1);
    
    for t = 1:4
        y_c = y_total; y_c(y_c <= 0) = 0.0001; % Sécurité logs
        try
            switch t
                case 1 % Lin
                    p = polyfit(x, y_total, 1);
                    p0_e = p(1); p1_e = p(2);
                case 2 % Log
                    p = polyfit(log(x), y_total, 1);
                    p0_e = p(1); p1_e = p(2);
                case 3 % Exp
                    p = polyfit(x, log(y_c), 1);
                    p1_e = p(1); p0_e = exp(p(2));
                case 4 % Puiss
                    p = polyfit(log(x), log(y_c), 1);
                    p0_e = p(1); p1_e = exp(p(2));
            end
            
            % Calcul du R²
            y_fit = simu_sys(x, t, p0_e, p1_e);
            SS_res = sum((y_total - y_fit).^2);
            SS_tot = sum((y_total - mean(y_total)).^2);
            scores_R2(t) = 1 - SS_res/SS_tot;
            p0_all(t) = p0_e;
            p1_all(t) = p1_e;
        catch
            scores_R2(t) = -inf; % En cas d'erreur mathématique
        end
    end
    
    % Résultats finaux
    [~, meilleur_type] = max(scores_R2);
    p_estim = [p0_all(meilleur_type), p1_all(meilleur_type)];
    
    % Estimation du bruit sur le meilleur modèle
    residus = y_total - simu_sys(x, meilleur_type, p_estim(1), p_estim(2));
    sigma_est = std(residus);
    
    % Création du tableau bilan
    tableau_R2 = table(noms', scores_R2, p0_all, p1_all, ...
        'VariableNames', {'Modele', 'R2', 'P0', 'P1'});
end

% =========================================================================
% TITRE : SOMME : Simulation complète signal + bruit + estimation
%
% Description :
%   Ce script interactif permet de générer un signal théorique selon un
%   modèle mathématique choisi, d'y ajouter un bruit gaussien, puis
%   d'estimer les paramètres du modèle à partir des données bruitées.
%   Il affiche les graphiques d'analyse et sauvegarde les résultats.
%
% Syntaxe :
%   somme
%
% Paramètres demandés à l'utilisateur :
%   n        : nombre de points (1 à 1000)
%   type_fct : type de modèle
%              1 : linéaire
%              2 : logarithmique
%              3 : exponentiel
%              4 : puissance
%   p0, p1   : paramètres du modèle
%   sigma    : intensité du bruit (≥ 0)
%
% Sorties :
%   - Graphiques d'analyse
%   - Paramètres estimés
%   - Erreurs statistiques
%   - Fichier CSV contenant les données simulées
%
% Exemple :
%   lancer simplement :
%   >> somme
%
% Remarques :
%   - Utilise les fonctions externes :
%         simu_sys.m
%         bruit.m
%   - Nécessite au moins 2 points pour effectuer une estimation
%
% Auteur : VALENTIN
% Date création : 2026-02-16
% Version : 21
% =========================================================================


% 1. SAISIE DES DONNÉES UTILISATEUR AVEC CONTRÔLES DE SÉCURITÉ

n = 0; % Initialisation
while (n < 1 || n > 1000) % boucle jusqu'à entrée valide
    n = input('Nombre de points (entre 1 et 1000) : ');
    if (n < 1 || n > 1000)
        disp('ERREUR : Choisissez un nombre raisonnable.');
    end
end

type_fct = 0; % initialisation
while ~ismember(type_fct, [1, 2, 3, 4]) % vérifie que le choix est valide
    type_fct = input('Modèle (1:Lin, 2:Log, 3:Exp, 4:Puiss) : ');
end

% Paramètres du modèle
p0 = input('Valeur de p0 : ');
p1 = input('Valeur de p1 : ');

% Intensité du bruit (sigma ≥ 0 obligatoire)
sigma = -1;
while sigma < 0
    sigma = input('Intensité du bruit (Avec Sigma supérieur ou égal 0) : ');
end

% 2. PRÉPARATION DU VECTEUR X

% Génère n points entre 0.1 et 30
% On commence à 0.1 pour éviter log(0) dans certains modèles
x = linspace(0.1, 30, n); 

% 3. CALCULS PRINCIPAUX

% bloc sécurisé contre erreurs mathématiques
try     
    % Génération du signal théorique pur
    y_pur = simu_sys(x, type_fct, p0, p1); 
    
    % AFFICHAGE SIGNAL PUR

    figure % Fenêtre 1 : Signal pur
    plot(x, y_pur, 'b-', 'LineWidth', 2)
    grid on
    title('Signal Pur (Modèle Théorique)');
    
    % 4. AJOUT DU BRUIT

    % Appel de bruit en mode ESCLAVE (on lui envoie n et sigma)
    b = bruit(n, sigma);

    % 5. Calcul de la somme et affichage final
    
    % Addition signal + bruit
    y_total = y_pur + b;
    
    % NUAGE DE POINTS
    figure % Fenêtre 3 : Nuage de points
    plot(x, y_total, 'r.')
    grid on
    title('Résultat Final (Données pour estimation)');

    % COMPARAISON VISUELLE
    figure
    plot(x, y_total, 'r.', 'MarkerSize', 8) % données bruitées
    hold on % Permet de dessiner par-dessus
    plot(x, y_pur, 'b-', 'LineWidth', 2)   % La ligne théorique
    grid on
    legend('Données bruitées (Réalité)', 'Modèle pur (Théorie)')
    title('Comparaison Signal / Bruit')
    
    % 6. ERREUR QUADRATIQUE MOYENNE

    % Calcul de l'écart entre le signal réel et le signal pur
    erreur = y_total - y_pur; % différence point à point
    eqm = mean(erreur.^2); % moyenne du carré des erreurs
    disp(['Erreur Quadratique Moyenne (EQM) : ', num2str(eqm)]);

% 7. ESTIMATION DES PARAMÈTRES

% ESTIMATION (tous modèles)
% Initialisation pour éviter erreur si estimation échoue
p0_estim = NaN; 
p1_estim = NaN; % valeurs par défaut sécurité

    if n >= 2 % minimum nécessaire pour ajustement
        % Sécurité Log (on utilise une copie pour le calcul si bruit trop fort)
        y_c = y_total; 
        y_c(y_c <= 0) = 0.0001; % évite log négatif
        
        switch type_fct
        
        % LINÉAIRE (y = p0 * x + p1)
            case 1
                p_estim = polyfit(x, y_total, 1);
                p0_estim = p_estim(1);
                p1_estim = p_estim(2);

        % LOGARITHMIQUE (y = p0 * log(x) + p1)
            case 2
                p_estim = polyfit(log(x), y_total, 1);
                p0_estim = p_estim(1);
                p1_estim = p_estim(2);

        % EXPONENTIEL (y = p0 * exp(p1 * x))
            case 3
                p_estim = polyfit(x, log(y_c), 1);
                p1_estim = p_estim(1);
                p0_estim = exp(p_estim(2));
              

        % PUISSANCE (y = p1 * x^p0)
            case 4
                p_estim = polyfit(log(x), log(y_c), 1);
                p0_estim = p_estim(1);
                p1_estim = exp(p_estim(2));
                
        end

    % Affichage si estimation valide
        if ~isnan(p0_estim)
             disp(['Valeurs estimées : p0 = ', num2str(p0_estim),' , p1 = ', num2str(p1_estim)])
             disp(['Valeurs réelles :  p0 = ', num2str(p0),' , p1 = ', num2str(p1)])
        end
    else
        disp('Pas assez de points pour estimer');
    end

    % 8. TRACE MODÈLE ESTIMÉ

    % TRACER LA COURBE ESTIMÉE (La ligne verte) 
    % On ne trace que si le calcul a fonctionné
    if ~isnan(p0_estim)
        y_estim = simu_sys(x, type_fct, p0_estim, p1_estim);
        plot(x, y_estim, 'g--', 'LineWidth', 1.5) 
        legend('Données bruitées', 'Modèle théorique', 'Modèle estimé')
        title(['Analyse du modèle ', num2str(type_fct), ' - EQM: ', num2str(eqm)]);
    end
    
    % 9. ERREUR RELATIVE PARAMÈTRE

    % CALCUL DES ERREURS
    err_rel_p0 = NaN; % Par défaut
    if p0 ~= 0 && ~isnan(p0_estim)
        err_rel_p0 = abs((p0_estim - p0)/p0) * 100; % Sécurité division par zéro
    end
    
    disp(' ')
    disp(' ANALYSE DES RÉSULTATS ')
    disp(['Erreur Quadratique Moyenne (EQM) : ', num2str(eqm)])
    disp(['Valeurs estimées : p0 = ', num2str(p0_estim),' , p1 = ', num2str(p1_estim)])
    disp(['Erreur relative sur p0 (%) : ', num2str(err_rel_p0)])
    
    % 10. SAUVEGARDE CSV

    % Sauvegarde Excel
    % Création d'un tableau de résultats
    Resultats = table(x', y_pur', y_total', 'VariableNames', {'X', 'Signal_Pur', 'Signal_Bruite'});
    
    % Affichage des 5 premières lignes dans la console
    disp('Aperçu des données générées :');
    disp(head(Resultats, 5));

    % export fichier
    writetable(Resultats, 'donnees_simulation.csv');
    disp('Fichier donnees_simulation.csv enregistré !');

% GESTION ERREURS GLOBALES

catch ME
    disp(['ERREUR : ', ME.message]);
end

% function b = bruit(n)
% if nargin == 0
%     n = 100;
% end
% sigma = 0.1;
% b = sigma * randn(1, n);
% figure % Cette ligne va ouvrir une fenêtre automatiquement
% subplot(1,2,1)
% plot(b)
% title('Bruit gaussien')
% xlabel('n'); ylabel('Amplitude');
% subplot(1,2,2)
% histogram(b, 100)
% title('Histogramme du bruit')
% xlabel('Amplitude'); ylabel('Frequence');
% end
% 
% % --- SCRIPT COMPLET SÉCURISÉ (Fichier somme.m) ---
% 
% % 1. Saisie des données avec boucles de sécurité
% n = 0;
% while (n < 1 | n > 1000)
%     n = input('Nombre de points (entre 1 et 1000) : ');
%     if (n < 1 | n > 1000)
%         disp('ERREUR : Choisissez un nombre raisonnable pour éviter les bugs.');
%     end
% end
% 
% type_fct = 0;
% while ~ismember(type_fct, [1, 2, 3, 4])
%     type_fct = input('Modèle (1:Lin, 2:Log, 3:Exp, 4:Puiss) : ');
%     if ~ismember(type_fct, [1, 2, 3, 4])
%         disp('ERREUR : Le modèle doit être compris entre 1 et 4.');
%     end
% end
% 
% p0 = input('Valeur de p0 : ');
% p1 = input('Valeur de p1 : ');
% 
% % 2. Préparation de x
% x = linspace(0.1, 30, n); 
% 
% % 3. Appel de Simu_sys avec protection contre les erreurs de calcul
% try
%     y_pur = simu_sys(x, type_fct, p0, p1); 
% 
%     figure % Fenêtre pour le signal pur
%     plot(x, y_pur, 'b-', 'LineWidth', 2)
%     grid on
%     xlabel('x'); ylabel('y');
%     title('Signal Pur (Modèle Théorique)');
% 
%     % 4. Appel de bruit
%     b = bruit(n);
% 
%     % 5. Calcul de la somme et affichage
%     y_total = y_pur + b;
% 
%     figure 
%     plot(x, y_total, 'r.')
%     grid on
%     xlabel('x'); ylabel('y');
%     title('Résultat Final : Modèle + Bruit (Nuage de points)');
% 
% catch ME
%     disp(['ERREUR DE CALCUL : ', ME.message]);
%     disp('Vérifiez vos paramètres');
% end

% % --- SCRIPT COMPLET (Fichier somme.m) ---
% 
% % 1. Saisie des données
% n = input('Nombre de points : ');
% type_fct = input('Modèle (1:Lin, 2:Log, 3:Exp, 4:Puiss) : ');
% p0 = input('Valeur de p0 : ');
% p1 = input('Valeur de p1 : ');
% 
% % 2. Préparation de x
% x = linspace(0.1, 30, n); 
% 
% % 3. Appel de Simu_sys et AFFICHAGE DU SIGNAL PUR
% y_pur = simu_sys(x, type_fct, p0, p1); 
% 
% figure % Fenêtre pour le signal pur
% plot(x, y_pur, 'b-', 'LineWidth', 2)
% grid on
% xlabel('x'); ylabel('y');
% title('Signal Pur (Modèle Théorique)');
% 
% % 4. Appel de bruit (Affiche automatiquement les 2 graphiques du bruit)
% b = bruit(n);
% 
% % 5. Calcul de la somme et AFFICHAGE DU NUAGE DE POINTS
% y_total = y_pur + b;
% 
% figure % Fenêtre pour le résultat final
% plot(x, y_total, 'r.')
% grid on
% xlabel('x'); ylabel('y');
% title('Résultat Final : Modèle + Bruit (Nuage de points)');



% % --- SCRIPT INTERACTIF ---
% n = input('Nombre de points (ex: 100) : ');
% type_fct = input('Modèle (1:Lin, 2:Log, 3:Exp, 4:Puiss) : ');
% p0 = input('Valeur de p0 : ');
% p1 = input('Valeur de p1 : ');
% 
% % Calcul de x
% x = linspace(0.1, 30, n);
% 
% % Appel des fonctions
% y_pur = simu_sys(x, type_fct, p0, p1); 
% b = bruit(n);
% 
% % Calcul de la somme
% y_total = y_pur + b;
% 
% % Affichage
% figure
% plot(x, y_total, 'r.')
% grid on
% xlabel('x'); ylabel('y');
% title('Résultat de la simulation');



% function b = bruit(n)
% if nargin == 0
%     n = 100;
% end
% 
% sigma = 0.1;
% b = sigma * randn(1, n);
% 
% figure
% subplot(1,2,1)
% plot(b)
% title('Bruit gaussien')
% xlabel('n')
% ylabel('Amplitude')
% 
% subplot(1,2,2)
% histogram(b, 100)
% title('Histogramme du bruit')
% xlabel('Amplitude')
% ylabel('Frequence')
% end



% 
% function y = simu_sys(x, type_fct, p0, p1)
%     if type_fct == 1
%         % Modele Lineaire : y = ax + b [cite: 74, 112]
%         y = p0 * x + p1;
%     elseif type_fct == 2
%         % Modele Logarithmique
%         y = p0 * log(x) + p1;
%     elseif type_fct == 3
%         % Modele Exponentiel [cite: 76]
%         y = p0 * exp(p1 * x);
%     elseif type_fct == 4
%         % Modele Puissance [cite: 114]
%         y = p1 * x.^p0;
%     else
%         % Si ce n'est aucun des choix ci-dessus
%         error('Type inconnu');
%     end
% end
% 
% % Affichage de la réponse du système
% 
% figure
% plot(x, y, 'r')
% xlabel('x')
% ylabel('y')