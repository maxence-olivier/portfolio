function b = bruit(n, sigma, type_bruit, axes_temporel, axes_histogramme)
% Génère du bruit gaussien ou uniforme
% Si axes_temporel et axes_histogramme sont fournis → affichage IHM
% Sinon → fonction silencieuse, pas de figure externe

if nargin<5, axes_histogramme = []; end
if nargin<4, axes_temporel = []; end
if nargin<3, type_bruit = 1; end
if nargin<2, sigma = 0.1; end
if nargin<1, n = 100; end

% Bruit
if type_bruit == 1
    b = sigma*randn(1,n);
    nom_bruit = 'Gaussien';
else
    b = sigma*(rand(1,n)-0.5)*2;
    nom_bruit = 'Uniforme';
end

% Affichage IHM uniquement
if ~isempty(axes_temporel) && ~isempty(axes_histogramme)
    % Signal temporel
    cla(axes_temporel); hold(axes_temporel,'on'); grid(axes_temporel,'on');
    plot(axes_temporel, b,'LineWidth',1.5);
    title(axes_temporel,['Signal du bruit : ', nom_bruit]);
    xlabel(axes_temporel,'Échantillons'); ylabel(axes_temporel,'Amplitude');

    % Histogramme
    cla(axes_histogramme); hold(axes_histogramme,'on'); grid(axes_histogramme,'on');
    histogram(axes_histogramme,b,50,'Normalization','pdf');

    x_axe = linspace(min(b), max(b),200);
    if type_bruit == 1
        y_theo = (1/(sigma*sqrt(2*pi))) * exp(-0.5*(x_axe/sigma).^2);
    else
        y_theo = ones(size(x_axe))*(1/(2*sigma));
    end
    plot(axes_histogramme, x_axe, y_theo,'r','LineWidth',2);
    legend(axes_histogramme,'Bruit mesuré','Loi théorique');
end
