% =========================================================================
% TITRE : SOMME : Simulation complète signal + bruit + estimation
%
% Description :
%   Ce script interactif permet de générer un signal théorique selon un
%   modèle mathématique choisi, d'y ajouter un bruit gaussien, puis
%   d'estimer les paramètres du modèle à partir des données bruitées.
%   Il affiche les graphiques d'analyse et sauvegarde les résultats.
%
% Syntaxe :
%   somme
%
% Paramètres demandés à l'utilisateur :
%   n        : nombre de points (1 à 1000)
%   type_fct : type de modèle
%              1 : linéaire
%              2 : logarithmique
%              3 : exponentiel
%              4 : puissance
%   p0, p1   : paramètres du modèle
%   sigma    : intensité du bruit (≥ 0)
%
% Sorties :
%   - Graphiques d'analyse
%   - Paramètres estimés
%   - Erreurs statistiques
%   - Fichier CSV contenant les données simulées
%
% Exemple :
%   lancer simplement :
%   >> somme
%
% Remarques :
%   - Utilise les fonctions externes :
%         simu_sys.m
%         bruit.m
%   - Nécessite au moins 2 points pour effectuer une estimation
%
% Auteur : VALENTIN
% Date création : 2026-02-16
% Version : 22
% =========================================================================

clear; 
clc; 
close all;

% 0. CHOIX DU MODE (RAJOUT POUR LIER L'ANALYSE)
fprintf(' MENU PRINCIPAL\n');

mode_choisi = 0; % Initialisation pour entrer dans la boucle
while ~ismember(mode_choisi, [1, 2])
    mode_choisi = input(['Choisissez entre :\n'...
                     '1: Simulation de nouvelles données\n'...
                     '2: Analyse automatique d''un fichier existant\n'...
                     'Votre choix : ']);
    if ~ismember(mode_choisi, [1, 2])
        disp('ERREUR : Veuillez taper 1 pour simuler ou 2 pour analyser.');
    end
end


 if mode_choisi == 2
    % MODE 2 : ANALYSE DE FICHIER
    try
        nom_fic = input('Nom du fichier CSV à analyser (ex: donnees_simulation.csv) : ', 's');
        data = readtable(nom_fic);
        
        % Extraction des données du CSV
        x = data.X';
        y_total = data.Signal_Bruite';
        
        

        analyse_automatique(x, y_total);

      
        return; % Fin du script pour le mode 2
        
    catch ME
        fprintf('ERREUR : %s\n', ME.message);
        return;
    end
 end
% else

    % 1. SAISIE DES DONNÉES UTILISATEUR AVEC CONTRÔLES DE SÉCURITÉ
    
    n = 0; % Initialisation
    while (n < 1 || n > 1000) % boucle jusqu'à entrée valide
        n = input('Nombre de points (entre 1 et 1000) : ');
        if (n < 1 || n > 1000)
            disp('ERREUR : Choisissez un nombre raisonnable.');
        end
    end
    
    type_fct = 0; % initialisation
    while ~ismember(type_fct, [1, 2, 3, 4]) % vérifie que le choix est valide
        type_fct = input('Modèle (1:Lin, 2:Log, 3:Exp, 4:Puiss) : ');
    end
    
    % Paramètres du modèle
    p0 = input('Valeur de p0 : ');
    p1 = input('Valeur de p1 : ');
    
    % Intensité du bruit (sigma ≥ 0 obligatoire)
    sigma = -1;
    while sigma < 0
        sigma = input('Intensité du bruit (Avec Sigma supérieur ou égal 0) : ');
    end

    % 2. PRÉPARATION DU VECTEUR X
    
    % Génère n points entre 0.1 et 30
    % On commence à 0.1 pour éviter log(0) dans certains modèles
    x = linspace(0.1, 30, n); 
    

    % 3. AJOUT : CHOIX DU TYPE DE BRUIT

    type_bruit = 0;
    while ~ismember(type_bruit, [1, 2])
        type_bruit = input(['Type de bruit :\n'... 
            '1: Gaussien\n'... 
            '2: Uniforme\n'...
            'Type de bruit choisi : ']);
    end
    
    % 4. CALCULS PRINCIPAUX
    
    % bloc sécurisé contre erreurs mathématiques
    try     
        % Génération du signal théorique pur
        y_pur = simu_sys(x, type_fct, p0, p1); 
        
        % % 5. AJOUT DU BRUIT
        % 
        % % Appel de bruit en mode ESCLAVE (on lui envoie n et sigma)
        % b = bruit(n, sigma, type_bruit);
        

        % % % Addition signal + bruit
        % y_total = y_pur + b;

        % AFFICHAGE SIGNAL PUR
    
        figure % Fenêtre 1 : Signal pur
        plot(x, y_pur, 'b-', 'LineWidth', 2)
        grid on
        title('Signal Pur (Modèle Théorique)');
        
        % % 5. AJOUT DU BRUIT
        % 
        % % Appel de bruit en mode ESCLAVE (on lui envoie n et sigma)
        b = bruit(n, sigma, type_bruit);
    
        % 6. Calcul de la somme et affichage final
        
        % % % Addition signal + bruit
        y_total = y_pur + b;
        
        % 6. Calcul de la somme et affichage final

        % NUAGE DE POINTS
        figure % Fenêtre 3 : Nuage de points
        plot(x, y_total, 'r.')
        grid on
        title('Données bruitées');
    
        % 7. COMPARAISON VISUELLE
    
        figure
        plot(x, y_total, 'r.', 'MarkerSize', 8) % données bruitées
        hold on % Permet de dessiner par-dessus
        plot(x, y_pur, 'b-', 'LineWidth', 2)   % La ligne théorique
        grid on
        legend('Données bruitées (Réalité)', 'Modèle pur (Théorie)')
        title('Comparaison Signal / Bruit')
        
        % 8. ERREUR QUADRATIQUE MOYENNE
    
        % Calcul de l'écart entre le signal réel et le signal pur
        erreur = y_total - y_pur; % différence point à point
        eqm = mean(erreur.^2); % moyenne du carré des erreurs
        disp(['Erreur Quadratique Moyenne (EQM) : ', num2str(eqm)]);
    
    % 9. ESTIMATION DES PARAMÈTRES
    
    % ESTIMATION (tous modèles)
    % Initialisation pour éviter erreur si estimation échoue
    p0_estim = NaN; 
    p1_estim = NaN; % valeurs par défaut sécurité
    
        if n >= 2 % minimum nécessaire pour ajustement
            % Sécurité Log (on utilise une copie pour le calcul si bruit trop fort)
            y_c = y_total; 
            y_c(y_c <= 0) = 0.0001; % évite log négatif
            
            switch type_fct
            
            % LINÉAIRE (y = p0 * x + p1)
                case 1
                    X = x;
                    Y = y_total;
                    mode = 1;
    
            % LOGARITHMIQUE (y = p0 * log(x) + p1)
                case 2
                    X = log(x);
                    Y = y_total;
                    mode = 2;
    
            % EXPONENTIEL (y = p0 * exp(p1 * x))
                case 3
                    X = x;
                    Y = log(y_c);
                    mode = 3; 
                  
    
            % PUISSANCE (y = p1 * x^p0)
                case 4
                    X = log(x);
                    Y = log(y_c);
                    mode = 4;            
            end
    
            % RÉGRESSION UNIQUE
            p = polyfit(X, Y, 1);
        
            A = p(1);
            B = p(2);
        
            % RETOUR PARAMÈTRES RÉELS
            switch mode
                
                case 1 % Linéaire
                    p0_estim = A;
                    p1_estim = B;
        
                case 2 % Log
                    p0_estim = A;
                    p1_estim = B;
        
                case 3 % Exp
                    p1_estim = A;
                    p0_estim = exp(B);
        
                case 4 % Puissance
                    p0_estim = A;
                    p1_estim = exp(B);
            end
    
        % Affichage si estimation valide
            if ~isnan(p0_estim)
                 disp(['Valeurs estimées : p0 = ', num2str(p0_estim),' , p1 = ', num2str(p1_estim)])
                 disp(['Valeurs réelles :  p0 = ', num2str(p0),' , p1 = ', num2str(p1)])
            end
        else
            disp('Pas assez de points pour estimer');
        end
    
        % 10. TRACE MODÈLE ESTIMÉ + R²
    
        % TRACER LA COURBE ESTIMÉE (La ligne verte) 
        % On ne trace que si le calcul a fonctionné
        if ~isnan(p0_estim)
            y_estim = simu_sys(x, type_fct, p0_estim, p1_estim);
    
            % calcul R²
            SS_res=sum((y_total-y_estim).^2);
            SS_tot=sum((y_total-mean(y_total)).^2);
            R2=1-SS_res/SS_tot;
    
            plot(x, y_estim, 'g--', 'LineWidth', 1.5) 
            legend('Données bruitées', 'Modèle théorique', 'Modèle estimé')
            title(['Analyse du modèle ', num2str(type_fct), ' - EQM: ', num2str(eqm), 'R²=',num2str(R2)]);
        end
    
        % 11. ANALYSE NUMÉRIQUE


        % ERREUR RELATIVE PARAMÈTRE
        % CALCUL DES ERREURS
        err_rel_p0 = NaN; % Par défaut
        if p0 ~= 0 && ~isnan(p0_estim)
            err_rel_p0 = abs((p0_estim - p0)/p0) * 100; % Sécurité division par zéro
        end
        
        disp(' ')
        disp(' ANALYSE DES RÉSULTATS ')
        disp(['Erreur Quadratique Moyenne (EQM) : ', num2str(eqm)])
        disp(['Valeurs estimées : p0 = ', num2str(p0_estim)])
        disp(['p1 estimé = ',num2str(p1_estim)])
        disp(['Erreur relative sur p0 (%) : ', num2str(err_rel_p0)])
                
        % 12. SAUVEGARDE CSV
    
        % Sauvegarde Excel
        % Création d'un tableau de résultats
        R2_col = repmat(R2,length(x),1);
        Resultats = table(x', y_pur', y_total', (y_total - y_estim)',R2_col, 'VariableNames', {'X', 'Signal_Pur', 'Signal_Bruite', 'Bruit_Extrait','R2'});
        
        % Affichage des 5 premières lignes dans la console
        disp('Aperçu des données générées :');
        disp(head(Resultats, 5));
    
        % export fichier
        writetable(Resultats, 'donnees_simulation.csv');
        disp('Fichier donnees_simulation.csv enregistré !');
    
    % GESTION ERREURS GLOBALES
    
    catch ME
        disp(['ERREUR : ', ME.message]);
    end